import streamlit as st
import sqlite3
import hashlib
import os
from datetime import datetime, date
from pathlib import Path
import pandas as pd

APP_DIR = Path(__file__).parent
DB_PATH = APP_DIR / "job_portal.db"
UPLOAD_DIR = APP_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

st.set_page_config(page_title="Job Portal and Recruitment Platform", page_icon="💼", layout="wide")

# ---------- Theme ----------
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
html, body, [class*="css"] { font-family: Inter, sans-serif; color: #111111; }
.stApp { background: #EAF8FF; color: #111111; }
[data-testid="stHeader"] { background: rgba(234,248,255,0.96); }
[data-testid="stToolbar"] { color: #111111; }
.hero { background: linear-gradient(120deg,#87CEEB,#FFFFFF); border:1px solid #69BDE3;
        border-radius:22px; padding:34px 36px; }
.hero h1 { color:#111111; font-size:2.5rem; line-height:1.15; margin:0 0 12px 0; }
.hero p { color:#111111; font-size:1.05rem; margin-bottom:0; }
.stat { background:#FFFFFF; border:1px solid #87CEEB; border-radius:16px; padding:18px; }
.stat-label { color:#222222; font-size:.9rem; }
.stat-value { color:#111111; font-size:1.8rem; font-weight:800; }
.job-card { background:#FFFFFF; border:1px solid #87CEEB; border-radius:16px; padding:18px; margin-bottom:12px; color:#111111; }
.pill { display:inline-block; background:#D9F2FF; color:#111111; padding:4px 10px; border:1px solid #87CEEB; border-radius:30px; font-size:.8rem; margin:2px 4px 2px 0; }
div.stButton > button[kind="primary"] { background:#87CEEB; color:#111111; border:1px solid #55ADD5; border-radius:10px; font-weight:700; }
div.stButton > button[kind="primary"]:hover { background:#68BFE5; color:#111111; border:1px solid #399CCB; }
div.stButton > button, div[data-testid="stFormSubmitButton"] button { color:#111111; }
section[data-testid="stSidebar"] { background:#87CEEB; }
section[data-testid="stSidebar"] * { color:#111111 !important; }
h1,h2,h3,h4,h5,h6,p,label,span,li,small { color:#111111; }
div[data-testid="stForm"] { background:#D9F2FF; border:1px solid #87CEEB; border-radius:14px; padding:20px; }
input, textarea { background-color:#FFFFFF !important; color:#111111 !important; border-color:#69BDE3 !important; }
div[data-baseweb="select"] > div { background-color:#FFFFFF !important; color:#111111 !important; border-color:#69BDE3 !important; }
[data-testid="stDataFrame"], [data-testid="stTable"] { background:#FFFFFF; color:#111111; }
[data-testid="stMetric"] { background:#FFFFFF; border:1px solid #87CEEB; border-radius:12px; padding:12px; }
[data-testid="stAlert"] { color:#111111; }
hr { border-color:#87CEEB; }
</style>
""", unsafe_allow_html=True)

# ---------- Database ----------
def db():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('Job Seeker','Employer','Administrator')),
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            company TEXT NOT NULL,
            category TEXT NOT NULL,
            location TEXT NOT NULL,
            employment_type TEXT NOT NULL,
            salary TEXT,
            experience TEXT,
            skills TEXT,
            description TEXT NOT NULL,
            employer_id INTEGER,
            status TEXT NOT NULL DEFAULT 'Active',
            deadline TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(employer_id) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS applications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id INTEGER NOT NULL,
            seeker_id INTEGER NOT NULL,
            cover_letter TEXT,
            resume_path TEXT,
            status TEXT NOT NULL DEFAULT 'Applied',
            applied_at TEXT NOT NULL,
            UNIQUE(job_id, seeker_id),
            FOREIGN KEY(job_id) REFERENCES jobs(id),
            FOREIGN KEY(seeker_id) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS saved_jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id INTEGER NOT NULL,
            seeker_id INTEGER NOT NULL,
            UNIQUE(job_id,seeker_id)
        );
        CREATE TABLE IF NOT EXISTS profiles (
            user_id INTEGER PRIMARY KEY,
            phone TEXT DEFAULT '',
            education TEXT DEFAULT '',
            skills TEXT DEFAULT '',
            experience TEXT DEFAULT '',
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
        """)
        # Demonstration listings are added once.
        count = c.execute("SELECT COUNT(*) FROM jobs").fetchone()[0]
        if count == 0:
            sample = [
                ("Python Developer","Northstar Technologies","Software Development","Bengaluru, Karnataka","Full-time","₹5–9 LPA","1–3 years","Python, Django, SQL","Build and maintain web applications, APIs, and database integrations."),
                ("UI/UX Designer","BrightPixel Studio","Design","Remote","Full-time","₹4–7 LPA","1–3 years","Figma, Wireframes, Prototyping","Design intuitive product experiences and collaborate with developers."),
                ("Data Analyst","InsightWorks","Data & Analytics","Hyderabad, Telangana","Full-time","₹4–8 LPA","0–2 years","SQL, Excel, Python, Power BI","Analyze business data and communicate actionable insights."),
                ("Digital Marketing Executive","YellowLeaf Media","Marketing","Pune, Maharashtra","Full-time","₹3–5 LPA","0–2 years","SEO, Content, Analytics","Plan campaigns, optimize content, and measure marketing performance."),
                ("HR Recruiter","PeopleBridge","Human Resources","Mumbai, Maharashtra","Full-time","₹3–6 LPA","1–3 years","Recruitment, Communication","Coordinate hiring, screen candidates, and support interview scheduling.")
            ]
            now = datetime.now().isoformat(timespec="seconds")
            c.executemany("""INSERT INTO jobs(title,company,category,location,employment_type,salary,experience,skills,description,status,created_at)
                VALUES(?,?,?,?,?,?,?,?,?,'Active',?)""", [(*x, now) for x in sample])

def hash_password(password):
    return hashlib.pbkdf2_hmac("sha256", password.encode(), b"jobportal-local-salt-v1", 180_000).hex()

def current_user():
    return st.session_state.get("user")

def money_or_text(x):
    return x if x else "Not specified"

init_db()

# ---------- Helpers ----------
def get_jobs(search="", location="", category="All categories", job_type="All types", sort="Newest first"):
    sql = "SELECT * FROM jobs WHERE status='Active'"
    args = []
    if search.strip():
        term = f"%{search.strip()}%"
        sql += " AND (title LIKE ? OR company LIKE ? OR skills LIKE ? OR description LIKE ?)"
        args += [term, term, term, term]
    if location.strip():
        sql += " AND location LIKE ?"; args.append(f"%{location.strip()}%")
    if category != "All categories":
        sql += " AND category=?"; args.append(category)
    if job_type != "All types":
        sql += " AND employment_type=?"; args.append(job_type)
    order = "created_at DESC"
    if sort == "Salary (text)": order = "salary DESC"
    if sort == "Company A–Z": order = "company ASC"
    sql += f" ORDER BY {order}"
    with db() as c:
        return c.execute(sql, args).fetchall()

def count_rows(table, where="", args=()):
    with db() as c:
        return c.execute(f"SELECT COUNT(*) FROM {table} {where}", args).fetchone()[0]

def get_categories():
    with db() as c:
        vals = [r[0] for r in c.execute("SELECT DISTINCT category FROM jobs ORDER BY category")]
    return ["All categories"] + vals

def show_job(job, user=None, key_prefix="job"):
    st.markdown(f"""
    <div class="job-card">
      <h3 style="margin:0;color:#111111">{job['title']}</h3>
      <div style="font-weight:600;margin:4px 0 8px">{job['company']} · 📍 {job['location']}</div>
      <span class="pill">{job['category']}</span><span class="pill">{job['employment_type']}</span>
      <span class="pill">{job['experience'] or 'Experience not specified'}</span>
      <p style="margin-top:10px">{job['description']}</p>
      <p><b>Salary:</b> {money_or_text(job['salary'])} &nbsp; <b>Skills:</b> {job['skills'] or 'Not specified'}</p>
    </div>
    """, unsafe_allow_html=True)
    col1, col2, col3 = st.columns([1,1,5])
    if user and user["role"] == "Job Seeker":
        with col1:
            if st.button("Apply", key=f"{key_prefix}_apply_{job['id']}", type="primary"):
                st.session_state["apply_job_id"] = job["id"]
                st.rerun()
        with col2:
            if st.button("☆ Save", key=f"{key_prefix}_save_{job['id']}"):
                try:
                    with db() as c:
                        c.execute("INSERT INTO saved_jobs(job_id,seeker_id) VALUES(?,?)", (job["id"], user["id"]))
                    st.success("Job saved.")
                except sqlite3.IntegrityError:
                    st.info("This job is already saved.")
    elif not user:
        with col1:
            st.caption("Sign in as a job seeker to apply.")

# ---------- Sidebar ----------
with st.sidebar:
    st.markdown("## 💼 CareerConnect")
    st.caption("Job Portal and Recruitment Platform")
    user = current_user()
    if user:
        st.success(f"Signed in as **{user['name']}**")
        st.caption(user["role"])
        page_options = ["Home", "Find Jobs"]
        if user["role"] == "Job Seeker":
            page_options += ["My Dashboard", "My Profile & Resume", "My Applications", "Saved Jobs"]
        elif user["role"] == "Employer":
            page_options += ["Employer Dashboard", "Post a Job", "Manage My Jobs"]
        else:
            page_options += ["Admin Dashboard", "Manage All Jobs", "Manage Users"]
        page = st.radio("Navigation", page_options, label_visibility="collapsed")
        if st.button("Log out", use_container_width=True):
            st.session_state.pop("user", None)
            st.session_state.pop("apply_job_id", None)
            st.rerun()
    else:
        page = st.radio("Navigation", ["Home", "Find Jobs", "Login", "Register"], label_visibility="collapsed")
    st.markdown("---")
    st.caption("Golden yellow · White · Navy")

# ---------- Header ----------
st.markdown('<div class="hero"><h1>Find Your Dream Job Today.</h1><p>Discover opportunities, connect with great companies, and take the next step in your career.</p></div>', unsafe_allow_html=True)
st.write("")

with db() as c:
    total_jobs = c.execute("SELECT COUNT(*) FROM jobs WHERE status='Active'").fetchone()[0]
    total_companies = c.execute("SELECT COUNT(DISTINCT company) FROM jobs WHERE status='Active'").fetchone()[0]
    total_seekers = c.execute("SELECT COUNT(*) FROM users WHERE role='Job Seeker'").fetchone()[0]
    total_apps = c.execute("SELECT COUNT(*) FROM applications").fetchone()[0]
s1,s2,s3,s4 = st.columns(4)
for col, label, val in [(s1,"Available jobs",total_jobs),(s2,"Hiring companies",total_companies),(s3,"Job seekers",total_seekers),(s4,"Applications",total_apps)]:
    with col:
        st.markdown(f'<div class="stat"><div class="stat-label">{label}</div><div class="stat-value">{val:,}</div></div>', unsafe_allow_html=True)
st.write("")

# ---------- Pages ----------
if page == "Home":
    left, right = st.columns([1.4,1])
    with left:
        st.subheader("Start your next chapter")
        st.write("Search thousands of possibilities by role, skill, or location. Save jobs and track your applications in one place.")
        with st.form("home_search"):
            q = st.text_input("Job title, skill, or company", placeholder="e.g. Python Developer")
            loc = st.text_input("Location", placeholder="e.g. Bengaluru or Remote")
            submitted = st.form_submit_button("Search Jobs", type="primary")
        if submitted:
            st.session_state["home_q"] = q
            st.session_state["home_loc"] = loc
            st.session_state["nav_find"] = True
            st.info("Open **Find Jobs** in the sidebar to view matching results.")
        if not current_user():
            a,b = st.columns(2)
            with a:
                if st.button("Create Job Seeker Account", type="primary", use_container_width=True):
                    st.session_state["go_register"] = True
                    st.rerun()
            with b:
                if st.button("Employer? Register", use_container_width=True):
                    st.session_state["go_register_employer"] = True
                    st.rerun()
    with right:
        st.markdown("### Popular categories")
        for icon, name in [("💻","Software Development"),("🎨","Design"),("📊","Data & Analytics"),("📣","Marketing"),("🤝","Human Resources")]:
            st.markdown(f'<div class="job-card" style="padding:10px 14px;margin-bottom:8px">{icon} &nbsp; <b>{name}</b></div>', unsafe_allow_html=True)
    st.subheader("Featured opportunities")
    featured = get_jobs()[:3]
    if featured:
        for j in featured:
            show_job(j, current_user(), "home")
    else:
        st.info("No active jobs yet. Employers can post the first vacancy.")
    st.subheader("Career tips")
    t1,t2,t3 = st.columns(3)
    t1.info("**Tailor your resume**\n\nHighlight skills that match each job description.")
    t2.info("**Prepare examples**\n\nUse specific results to demonstrate your impact.")
    t3.info("**Keep applying**\n\nTrack each application and follow up professionally.")

elif page == "Find Jobs":
    st.subheader("Find your next opportunity")
    with st.form("job_filters"):
        c1,c2 = st.columns(2)
        with c1:
            q = st.text_input("Keywords", value=st.session_state.get("home_q",""), placeholder="Title, skills, company")
            loc = st.text_input("Location", value=st.session_state.get("home_loc",""), placeholder="City, state, or Remote")
            category = st.selectbox("Category", get_categories())
        with c2:
            types = ["All types","Full-time","Part-time","Contract","Internship","Remote"]
            job_type = st.selectbox("Employment type", types)
            sort = st.selectbox("Sort by", ["Newest first","Company A–Z","Salary (text)"])
        search_btn = st.form_submit_button("Apply Filters", type="primary")
    jobs = get_jobs(q, loc, category, job_type, sort)
    st.write(f"**{len(jobs)}** job(s) found")
    if jobs:
        for j in jobs:
            show_job(j, current_user(), "find")
    else:
        st.warning("No jobs match these filters. Try a different keyword or clear some filters.")

elif page == "Login":
    st.subheader("Welcome back")
    with st.form("login_form"):
        email = st.text_input("Email address")
        password = st.text_input("Password", type="password")
        ok = st.form_submit_button("Log in", type="primary")
    if ok:
        with db() as c:
            row = c.execute("SELECT * FROM users WHERE lower(email)=lower(?)", (email.strip(),)).fetchone()
        if row and row["password_hash"] == hash_password(password):
            st.session_state["user"] = dict(row)
            st.success("Login successful.")
            st.rerun()
        else:
            st.error("Invalid email or password.")
    st.caption("For local demonstration, create an account using Register. Password reset/email delivery is not configured.")

elif page == "Register":
    st.subheader("Create your account")
    preset_role = "Employer" if st.session_state.pop("go_register_employer", False) else "Job Seeker"
    st.session_state.pop("go_register", None)
    with st.form("register_form"):
        name = st.text_input("Full name")
        email = st.text_input("Email address")
        role = st.selectbox("I want to join as", ["Job Seeker","Employer"])
        password = st.text_input("Password (minimum 8 characters)", type="password")
        confirm = st.text_input("Confirm password", type="password")
        submitted = st.form_submit_button("Create account", type="primary")
    if submitted:
        if not name.strip() or not email.strip() or "@" not in email:
            st.error("Enter your name and a valid email address.")
        elif len(password) < 8:
            st.error("Use a password with at least 8 characters.")
        elif password != confirm:
            st.error("Passwords do not match.")
        else:
            try:
                with db() as c:
                    c.execute("INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                              (name.strip(), email.strip().lower(), hash_password(password), role, datetime.now().isoformat(timespec="seconds")))
                    uid = c.execute("SELECT id FROM users WHERE email=?", (email.strip().lower(),)).fetchone()[0]
                    c.execute("INSERT INTO profiles(user_id) VALUES(?)", (uid,))
                st.success("Account created. Select Login in the sidebar to sign in.")
            except sqlite3.IntegrityError:
                st.error("An account with this email already exists.")

elif page == "My Dashboard":
    if not current_user() or current_user()["role"] != "Job Seeker":
        st.warning("Please log in as a job seeker.")
    else:
        u = current_user()
        st.subheader(f"Hello, {u['name']} 👋")
        with db() as c:
            apps = c.execute("SELECT COUNT(*) FROM applications WHERE seeker_id=?", (u["id"],)).fetchone()[0]
            saved = c.execute("SELECT COUNT(*) FROM saved_jobs WHERE seeker_id=?", (u["id"],)).fetchone()[0]
            profile = c.execute("SELECT * FROM profiles WHERE user_id=?", (u["id"],)).fetchone()
        a,b,d = st.columns(3)
        a.metric("Applications submitted", apps)
        b.metric("Saved jobs", saved)
        d.metric("Profile skills added", "Yes" if profile and profile["skills"] else "Not yet")
        st.markdown("### Recommended jobs")
        for j in get_jobs()[:4]:
            show_job(j, u, "dashboard")

elif page == "My Profile & Resume":
    u = current_user()
    if not u or u["role"] != "Job Seeker":
        st.warning("Please log in as a job seeker.")
    else:
        with db() as c:
            p = c.execute("SELECT * FROM profiles WHERE user_id=?", (u["id"],)).fetchone()
        st.subheader("Profile & resume")
        with st.form("profile_form"):
            phone = st.text_input("Phone", value=p["phone"] or "")
            education = st.text_area("Education", value=p["education"] or "")
            skills = st.text_area("Skills", value=p["skills"] or "")
            experience = st.text_area("Experience and projects", value=p["experience"] or "")
            save_profile = st.form_submit_button("Save profile", type="primary")
        if save_profile:
            with db() as c:
                c.execute("UPDATE profiles SET phone=?,education=?,skills=?,experience=? WHERE user_id=?",
                          (phone, education, skills, experience, u["id"]))
            st.success("Profile updated.")
        st.markdown("### Upload resume (PDF)")
        upload = st.file_uploader("Choose a PDF resume (maximum 5 MB)", type=["pdf"])
        if upload:
            if upload.size > 5 * 1024 * 1024:
                st.error("File exceeds 5 MB.")
            elif not upload.getvalue().startswith(b"%PDF"):
                st.error("The uploaded file does not appear to be a valid PDF.")
            else:
                safe_name = f"user_{u['id']}_{int(datetime.now().timestamp())}.pdf"
                dest = UPLOAD_DIR / safe_name
                dest.write_bytes(upload.getvalue())
                st.session_state[f"resume_{u['id']}"] = str(dest)
                st.success("Resume uploaded for this session. You can attach it to applications.")
        resume = st.session_state.get(f"resume_{u['id']}")
        if resume and os.path.exists(resume):
            st.download_button("Download current uploaded resume", Path(resume).read_bytes(), file_name="resume.pdf", mime="application/pdf")

elif page == "My Applications":
    u = current_user()
    if not u or u["role"] != "Job Seeker":
        st.warning("Please log in as a job seeker.")
    else:
        with db() as c:
            rows = c.execute("""SELECT a.*,j.title,j.company,j.location FROM applications a JOIN jobs j ON j.id=a.job_id
                                WHERE a.seeker_id=? ORDER BY a.applied_at DESC""", (u["id"],)).fetchall()
        st.subheader("My applications")
        if rows:
            st.dataframe(pd.DataFrame([dict(r) for r in rows])[["title","company","location","status","applied_at"]], use_container_width=True, hide_index=True)
        else:
            st.info("You haven't applied to any jobs yet.")

elif page == "Saved Jobs":
    u = current_user()
    if not u or u["role"] != "Job Seeker":
        st.warning("Please log in as a job seeker.")
    else:
        with db() as c:
            rows = c.execute("SELECT j.* FROM jobs j JOIN saved_jobs s ON s.job_id=j.id WHERE s.seeker_id=? ORDER BY s.id DESC", (u["id"],)).fetchall()
        st.subheader("Saved jobs")
        if rows:
            for j in rows: show_job(j, u, "saved")
        else: st.info("Save jobs from Find Jobs to see them here.")

elif page == "Employer Dashboard":
    u = current_user()
    if not u or u["role"] != "Employer":
        st.warning("Please log in as an employer.")
    else:
        with db() as c:
            jobs_n = c.execute("SELECT COUNT(*) FROM jobs WHERE employer_id=?", (u["id"],)).fetchone()[0]
            apps_n = c.execute("SELECT COUNT(*) FROM applications a JOIN jobs j ON j.id=a.job_id WHERE j.employer_id=?", (u["id"],)).fetchone()[0]
            recent = c.execute("""SELECT a.id,j.title,u.name candidate,a.status,a.applied_at FROM applications a
                JOIN jobs j ON j.id=a.job_id JOIN users u ON u.id=a.seeker_id WHERE j.employer_id=? ORDER BY a.applied_at DESC LIMIT 10""", (u["id"],)).fetchall()
        a,b = st.columns(2); a.metric("Jobs posted", jobs_n); b.metric("Applications received", apps_n)
        st.subheader("Recent applications")
        if recent: st.dataframe(pd.DataFrame([dict(r) for r in recent]), use_container_width=True, hide_index=True)
        else: st.info("No applications received yet.")

elif page == "Post a Job":
    u = current_user()
    if not u or u["role"] != "Employer":
        st.warning("Log in as an employer to post jobs.")
    else:
        st.subheader("Post a new job")
        with st.form("post_job"):
            title = st.text_input("Job title")
            company = st.text_input("Company name")
            category = st.selectbox("Category", ["Software Development","Design","Data & Analytics","Marketing","Human Resources","Sales","Finance","Healthcare","Education","Other"])
            location = st.text_input("Location", placeholder="City, State or Remote")
            employment = st.selectbox("Employment type", ["Full-time","Part-time","Contract","Internship","Remote"])
            salary = st.text_input("Salary range", placeholder="e.g. ₹5–8 LPA")
            experience = st.text_input("Experience", placeholder="e.g. 1–3 years")
            skills = st.text_input("Required skills", placeholder="Python, SQL, communication")
            deadline = st.date_input("Application deadline", value=date.today())
            description = st.text_area("Job description", height=150)
            submit = st.form_submit_button("Publish job", type="primary")
        if submit:
            if not all([title.strip(),company.strip(),location.strip(),description.strip()]):
                st.error("Please fill in job title, company, location, and description.")
            else:
                with db() as c:
                    c.execute("""INSERT INTO jobs(title,company,category,location,employment_type,salary,experience,skills,description,employer_id,status,deadline,created_at)
                        VALUES(?,?,?,?,?,?,?,?,?,?,'Active',?,?)""",
                        (title.strip(),company.strip(),category,location.strip(),employment,salary,experience,skills,description,u["id"],str(deadline),datetime.now().isoformat(timespec="seconds")))
                st.success("Job published successfully.")

elif page == "Manage My Jobs":
    u = current_user()
    if not u or u["role"] != "Employer":
        st.warning("Log in as an employer.")
    else:
        with db() as c:
            rows = c.execute("SELECT * FROM jobs WHERE employer_id=? ORDER BY created_at DESC", (u["id"],)).fetchall()
        st.subheader("Manage my jobs")
        if rows:
            for j in rows:
                with st.expander(f"{j['title']} — {j['company']} ({j['status']})"):
                    st.write(j["description"])
                    st.caption(f"{j['location']} · {j['employment_type']} · {j['salary']}")
                    c1,c2 = st.columns(2)
                    with c1:
                        new_status = st.selectbox("Status", ["Active","Closed"], index=0 if j["status"]=="Active" else 1, key=f"status_{j['id']}")
                        if st.button("Update status", key=f"update_{j['id']}"):
                            with db() as c: c.execute("UPDATE jobs SET status=? WHERE id=? AND employer_id=?", (new_status,j["id"],u["id"]))
                            st.success("Status updated."); st.rerun()
                    with c2:
                        if st.button("Delete job", key=f"delete_{j['id']}"):
                            with db() as c:
                                c.execute("DELETE FROM applications WHERE job_id=?", (j["id"],))
                                c.execute("DELETE FROM saved_jobs WHERE job_id=?", (j["id"],))
                                c.execute("DELETE FROM jobs WHERE id=? AND employer_id=?", (j["id"],u["id"]))
                            st.success("Job deleted."); st.rerun()
                    with db() as c:
                        apps = c.execute("""SELECT a.id,a.status,a.applied_at,u.name,u.email,a.cover_letter FROM applications a JOIN users u ON u.id=a.seeker_id WHERE a.job_id=? ORDER BY a.applied_at DESC""", (j["id"],)).fetchall()
                    st.markdown("**Applicants**")
                    for app in apps:
                        st.write(f"{app['name']} · {app['email']} · {app['status']} · {app['applied_at']}")
                        status_options = ["Applied","Under Review","Shortlisted","Interview Scheduled","Selected","Rejected"]
                        chosen = st.selectbox("Application status", status_options, index=status_options.index(app["status"]) if app["status"] in status_options else 0, key=f"appstatus_{app['id']}")
                        if st.button("Save application status", key=f"saveapp_{app['id']}"):
                            with db() as c: c.execute("UPDATE applications SET status=? WHERE id=?", (chosen,app["id"]))
                            st.success("Application status updated."); st.rerun()
        else: st.info("You have not posted any jobs yet.")

elif page == "Admin Dashboard":
    u = current_user()
    if not u or u["role"] != "Administrator":
        st.warning("Administrator access required.")
    else:
        st.subheader("Administrator dashboard")
        with db() as c:
            users_n = c.execute("SELECT COUNT(*) FROM users").fetchone()[0]
            jobs_n = c.execute("SELECT COUNT(*) FROM jobs").fetchone()[0]
            apps_n = c.execute("SELECT COUNT(*) FROM applications").fetchone()[0]
            employers_n = c.execute("SELECT COUNT(*) FROM users WHERE role='Employer'").fetchone()[0]
        a,b,c1,d = st.columns(4)
        a.metric("Users",users_n); b.metric("Employers",employers_n); c1.metric("Jobs",jobs_n); d.metric("Applications",apps_n)
        with db() as c:
            by_status = pd.read_sql_query("SELECT status,COUNT(*) AS total FROM applications GROUP BY status", c)
            by_category = pd.read_sql_query("SELECT category,COUNT(*) AS total FROM jobs GROUP BY category", c)
        if not by_status.empty:
            st.markdown("### Application statuses"); st.bar_chart(by_status.set_index("status"))
        if not by_category.empty:
            st.markdown("### Jobs by category"); st.bar_chart(by_category.set_index("category"))

elif page == "Manage All Jobs":
    u = current_user()
    if not u or u["role"] != "Administrator":
        st.warning("Administrator access required.")
    else:
        with db() as c: rows = c.execute("SELECT * FROM jobs ORDER BY created_at DESC").fetchall()
        st.subheader("All job listings")
        for j in rows:
            with st.expander(f"{j['title']} — {j['company']} ({j['status']})"):
                st.write(j["description"])
                status = st.selectbox("Job status", ["Active","Closed","Pending"], index=["Active","Closed","Pending"].index(j["status"]) if j["status"] in ["Active","Closed","Pending"] else 0, key=f"adminstatus_{j['id']}")
                if st.button("Update", key=f"adminupdate_{j['id']}"):
                    with db() as c: c.execute("UPDATE jobs SET status=? WHERE id=?", (status,j["id"]))
                    st.success("Updated."); st.rerun()

elif page == "Manage Users":
    u = current_user()
    if not u or u["role"] != "Administrator":
        st.warning("Administrator access required.")
    else:
        with db() as c: rows = c.execute("SELECT id,name,email,role,created_at FROM users ORDER BY created_at DESC").fetchall()
        st.subheader("User management")
        if rows: st.dataframe(pd.DataFrame([dict(r) for r in rows]), use_container_width=True, hide_index=True)
        st.caption("For security, user passwords are never displayed.")

# Application dialog-like section, triggered from job cards.
job_to_apply = st.session_state.get("apply_job_id")
u = current_user()
if job_to_apply and u and u["role"] == "Job Seeker":
    with db() as c:
        job = c.execute("SELECT * FROM jobs WHERE id=?", (job_to_apply,)).fetchone()
    if job:
        st.divider()
        st.subheader(f"Apply for {job['title']} at {job['company']}")
        resume_path = st.session_state.get(f"resume_{u['id']}")
        with st.form(f"apply_form_{job_to_apply}"):
            cover = st.text_area("Cover letter (optional)", height=120)
            attach_resume = st.checkbox("Attach my currently uploaded resume", value=bool(resume_path and os.path.exists(resume_path)))
            apply_submit = st.form_submit_button("Submit application", type="primary")
        if apply_submit:
            try:
                with db() as c:
                    c.execute("INSERT INTO applications(job_id,seeker_id,cover_letter,resume_path,status,applied_at) VALUES(?,?,?,?,?,?)",
                              (job_to_apply,u["id"],cover,resume_path if attach_resume else None,"Applied",datetime.now().isoformat(timespec="seconds")))
                st.success("Application submitted successfully.")
                st.session_state.pop("apply_job_id", None)
                st.rerun()
            except sqlite3.IntegrityError:
                st.error("You have already applied for this job.")
        if st.button("Cancel application form"):
            st.session_state.pop("apply_job_id", None)
            st.rerun()

st.markdown("---")
st.markdown("<div style='text-align:center;color:#111111;padding:12px'>© 2026 Job Portal and Recruitment Platform · Find opportunities. Build your future.</div>", unsafe_allow_html=True)
