# Job Portal and Recruitment Platform — Streamlit

A local Streamlit job portal with a golden-yellow, white, and navy design.

## Features
- Responsive homepage, job search and filters
- Job seeker and employer registration/login
- SQLite database created automatically
- Sample vacancies seeded on first run
- Job seeker profile fields and PDF resume upload
- Job applications, duplicate-application prevention, saved jobs
- Employer job posting, closing/deleting jobs, applicant status updates
- Basic administrator dashboards and charts

## Run on Windows
1. Install Python 3.10 or newer.
2. Extract this folder and open it in VS Code.
3. Open Terminal in the folder:
   ```powershell
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   streamlit run app.py
   ```
4. Open the local URL shown by Streamlit (usually http://localhost:8501).

## Create an administrator account
1. Register a regular account in the app.
2. Stop Streamlit with Ctrl+C.
3. Open `job_portal.db` with a SQLite database browser or run a SQLite command to change that account's role:
   ```sql
   UPDATE users SET role='Administrator' WHERE email='your-email@example.com';
   ```
4. Restart Streamlit and log in again.

## Notes
- This Streamlit version uses SQLite to make local setup simple; it does not use Django or MySQL.
- Email delivery, password reset, interview scheduling, production-grade PDF generation, and hardened multi-user security are not implemented.
- Uploaded resumes are stored in the local `uploads` folder. Do not expose this development app publicly without adding appropriate security and access controls.
